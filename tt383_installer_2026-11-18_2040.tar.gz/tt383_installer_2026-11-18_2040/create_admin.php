<?php
/*
 * create_admin.php - creates the first (owner) account of a new TorrentTrader 3.8.3 site.
 * Called by install.sh from the command line; all values come from environment variables:
 *   TT_DBHOST TT_DBUSER TT_DBPASS TT_DBNAME
 *   TT_ADMIN_USER TT_ADMIN_EMAIL TT_ADMIN_PASS TT_ADMIN_CLASS TT_THEME TT_LANG
 *
 * The password is hashed with Argon2id (same as tt_hash_password() in backend/functions.php).
 * Columns of the users table that must have a value but have no default get an
 * empty value of the right type, so this works with every version of the table.
 */

if (PHP_SAPI !== 'cli')
	exit("Command line only.\n");

$env = static function (string $k, string $def = ''): string {
	$v = getenv($k);
	return $v === false ? $def : $v;
};

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
	$db = new mysqli($env('TT_DBHOST', 'localhost'), $env('TT_DBUSER'), $env('TT_DBPASS'), $env('TT_DBNAME'));
	$db->set_charset('utf8mb4');
} catch (Throwable $e) {
	fwrite(STDERR, "Database connection failed: " . $e->getMessage() . "\n");
	exit(1);
}

$user  = $env('TT_ADMIN_USER');
$email = $env('TT_ADMIN_EMAIL');
$pass  = $env('TT_ADMIN_PASS');
if ($user === '' || $email === '' || strlen($pass) < 6) {
	fwrite(STDERR, "Username, e-mail and a password of at least 6 characters are required.\n");
	exit(1);
}

// random strings for the account
$rand = static function (int $len): string {
	$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	$out = '';
	for ($i = 0; $i < $len; $i++)
		$out .= $chars[random_int(0, strlen($chars) - 1)];
	return $out;
};

$values = array(
	'username'    => $user,
	'password'    => password_hash($pass, PASSWORD_ARGON2ID, array('memory_cost' => 1 << 16, 'time_cost' => 4, 'threads' => 2)),
	'secret'      => $rand(20),
	'email'       => $email,
	'status'      => 'confirmed',
	'enabled'     => 'yes',
	'class'       => (int) $env('TT_ADMIN_CLASS', '7'),
	'added'       => gmdate('Y-m-d H:i:s'),
	'last_login'  => gmdate('Y-m-d H:i:s'),
	'last_access' => gmdate('Y-m-d H:i:s'),
	'stylesheet'  => (int) $env('TT_THEME', '1'),
	'language'    => (int) $env('TT_LANG', '1'),
	'privacy'     => 'normal',
	'passkey'     => md5($rand(32) . microtime()),
);

// columns of the users table
$cols = array();
$res = $db->query("SELECT COLUMN_NAME, IS_NULLABLE, COLUMN_DEFAULT, DATA_TYPE, COLUMN_TYPE, EXTRA
                   FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users'");
while ($c = $res->fetch_assoc())
	$cols[$c['COLUMN_NAME']] = $c;
if (!$cols) {
	fwrite(STDERR, "Table users does not exist - import the database first.\n");
	exit(1);
}

// keep only values for columns that exist
$values = array_intersect_key($values, $cols);

// required columns without a default value get an empty value of the right type
foreach ($cols as $name => $c) {
	if (isset($values[$name]) || $c['IS_NULLABLE'] === 'YES' || $c['COLUMN_DEFAULT'] !== null || str_contains($c['EXTRA'], 'auto_increment'))
		continue;
	$t = strtolower($c['DATA_TYPE']);
	if (in_array($t, array('int', 'tinyint', 'smallint', 'mediumint', 'bigint', 'decimal', 'float', 'double', 'bit'), true))
		$values[$name] = 0;
	elseif (in_array($t, array('datetime', 'timestamp'), true))
		$values[$name] = gmdate('Y-m-d H:i:s');
	elseif ($t === 'date')
		$values[$name] = gmdate('Y-m-d');
	elseif ($t === 'enum' && preg_match("/^enum\('([^']*)'/i", $c['COLUMN_TYPE'], $m))
		$values[$name] = $m[1];
	else
		$values[$name] = '';
}

$exists = $db->prepare("SELECT id FROM users WHERE username = ?");
$exists->bind_param('s', $user);
$exists->execute();
if ($exists->get_result()->fetch_row()) {
	fwrite(STDERR, "User '$user' already exists.\n");
	exit(1);
}

$names = '`' . implode('`, `', array_keys($values)) . '`';
$marks = implode(', ', array_fill(0, count($values), '?'));
$stmt = $db->prepare("INSERT INTO users ($names) VALUES ($marks)");
$types = '';
foreach ($values as $v)
	$types .= is_int($v) ? 'i' : 's';
$params = array_values($values);
$stmt->bind_param($types, ...$params);
$stmt->execute();

echo "Owner account '$user' created (id " . $db->insert_id . ", class " . $values['class'] . ").\n";
