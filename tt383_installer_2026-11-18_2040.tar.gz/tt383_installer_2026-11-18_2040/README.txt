TorrentTrader 3.8.3 (luigi build) - installer
==============================================

WHAT IS IN THIS FOLDER
  install.sh         the installer (run as root)
  create_admin.php   makes the owner account (called by install.sh)
  site.tar.gz        site files - no avatars, no uploaded torrents/pictures,
                     no cache, no logs, no API keys, no passwords
  database/          schema.sql = all tables (empty)
                     data.sql   = basic settings only: categories, groups,
                                  themes, languages, blocks, FAQ, rules,
                                  countries, forum structure, the System account
  meta.env           build information (version, owner class, default theme)

NEEDED ON THE NEW SERVER
  - Apache (or nginx + Apache) with PHP 8.3+ (8.5 tested), mysqli, gd, curl, mbstring
  - MariaDB 10.6+ / MySQL 8
  - a domain with its web folder (e.g. made in CWP / cPanel)

INSTALL
  tar -xzf tt383_installer_<date>.tar.gz
  cd tt383_installer_<date>
  bash install.sh

  The installer asks for the domain, the web folder, the site name / e-mail,
  the database (name, user, password) and the owner account.
  If root can use MySQL it creates the database and the user itself;
  otherwise make them in the panel first.

AFTER THE INSTALL
  1. Open the site and log in with the owner account.
  2. Optional keys in backend/config.php (they are empty on purpose):
       $site_config['OMDB_API_KEY']     https://www.omdbapi.com/apikey.aspx
       $site_config['TMDB_API_KEY']     https://www.themoviedb.org/settings/api
       $site_config['TMDB_READ_TOKEN']
       $site_config['YOUTUBE_API_KEY']  Google Cloud console - YouTube Data API v3
       $site_config['CLOUDSITEKEY'] / ['CLOUDSECRET']   Cloudflare Turnstile
       $site_config['mail_smtp_user'] / ['mail_smtp_pass']  e-mail sending
  3. Admin CP: check the site settings, categories and blocks.
  4. Cron for the cleanup (every 10 minutes), e.g. for user "example":
       */10 * * * * curl -s https://example.com/index.php >/dev/null 2>&1
  5. Delete this installer folder from the server when everything works.
