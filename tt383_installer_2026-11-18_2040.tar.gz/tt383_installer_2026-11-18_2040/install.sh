#!/bin/bash
# =====================================================================
#  install.sh - installs TorrentTrader 3.8.3 (luigi build) on a new domain
#
#  Run as root on the target server, from the unpacked installer folder:
#     tar -xzf tt383_installer_<date>.tar.gz
#     cd tt383_installer_<date>
#     bash install.sh
#
#  It asks for: domain, web folder, site name / e-mail, database and the
#  owner account. Then it:
#     1. unpacks the site files into the web folder
#     2. writes backend/mysql.php and the site data in backend/config.php
#     3. creates the database and its user (if root can do that) and imports
#        the table structure + basic settings
#     4. creates the owner account
#     5. sets owner and rights of the files and the writable folders
#  API keys (OMDb, TMDb, YouTube), Cloudflare and SMTP stay EMPTY - fill them in
#  backend/config.php later.
# =====================================================================

set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
[ -f "$HERE/site.tar.gz" ] && [ -f "$HERE/database/schema.sql" ] || { echo "Run this from the unpacked installer folder."; exit 1; }
[ "$(id -u)" = "0" ] || { echo "Run as root."; exit 1; }
# shellcheck disable=SC1091
. "$HERE/meta.env"

PHP="/opt/remi/php85/root/usr/bin/php"; [ -x "$PHP" ] || PHP="$(command -v php || true)"
[ -n "$PHP" ] || { echo "PHP (command line) not found."; exit 1; }

eof() { echo; echo "Input ended - stopped, nothing changed."; exit 1; }
ask() {   # ask "question" "default" -> REPLY
  local q="$1" d="${2:-}"
  if [ -n "$d" ]; then read -r -p "$q [$d]: " REPLY || eof; REPLY="${REPLY:-$d}"; else read -r -p "$q: " REPLY || eof; fi
}
ask_secret() {
  local a b
  while :; do
    read -r -s -p "$1: " a || eof; echo
    read -r -s -p "   again: " b || eof; echo
    [ "$a" = "$b" ] && [ ${#a} -ge 6 ] && { REPLY="$a"; return; }
    echo "   Not the same or shorter than 6 characters - try again."
  done
}
sq() { printf "%s" "$1" | sed "s/\\\\/\\\\\\\\/g; s/'/\\\\'/g"; }   # escape for a PHP '...' string

echo "== TorrentTrader $TT_VERSION installer (built $BUILT)"
echo

ask "Domain (without https://, e.g. example.com)"; DOMAIN="${REPLY#http*://}"; DOMAIN="${DOMAIN%%/*}"
[ -n "$DOMAIN" ] || { echo "Domain is required."; exit 1; }
GUESS_USER="$(echo "$DOMAIN" | cut -d. -f1 | tr -cd 'a-z0-9' | cut -c1-8)"
ask "Web folder of the domain" "/home/$GUESS_USER/public_html"; DOCROOT="${REPLY%/}"
ask "Site name" "$DOMAIN"; SITENAME="$REPLY"
ask "Site e-mail (sender)" "noreply@$DOMAIN"; SITEEMAIL="$REPLY"
ask "Site address" "https://$DOMAIN"; SITEURL="${REPLY%/}"
echo
ask "Database name" "${GUESS_USER}_tt"; DBNAME="$REPLY"
ask "Database user" "${GUESS_USER}_tt"; DBUSER="$REPLY"
ask_secret "Database password"; DBPASS="$REPLY"
echo
ask "Owner account - username" "admin"; AUSER="$REPLY"
ask "Owner account - e-mail" "$SITEEMAIL"; AEMAIL="$REPLY"
ask_secret "Owner account - password"; APASS="$REPLY"

if [ -d "$DOCROOT" ]; then
  OWNER="$(stat -c %U "$DOCROOT")"; GROUP="$(stat -c %G "$DOCROOT")"
else
  OWNER="$(stat -c %U "$(dirname "$DOCROOT")" 2>/dev/null || echo root)"; GROUP="$OWNER"
fi

echo
echo "-------------------------------------------------------------"
echo " Domain:       $DOMAIN   ($SITEURL)"
echo " Web folder:   $DOCROOT   (owner $OWNER:$GROUP)"
echo " Database:     $DBNAME / $DBUSER"
echo " Owner:        $AUSER <$AEMAIL>"
echo "-------------------------------------------------------------"
if [ -d "$DOCROOT" ] && [ -n "$(ls -A "$DOCROOT" 2>/dev/null | grep -vxE 'cgi-bin|\.well-known|index\.html|default\.htm|\.htaccess')" ]; then
  echo " WARNING: $DOCROOT is not empty - files with the same name will be overwritten."
fi
ask "Install now? (yes/no)" "no"; [ "$REPLY" = "yes" ] || { echo "Stopped, nothing changed."; exit 0; }

# ---------------------------------------------------------------------
echo; echo "== 1. Site files"
mkdir -p "$DOCROOT"
tar -xzf "$HERE/site.tar.gz" -C "$DOCROOT" || { echo "Unpacking failed."; exit 1; }

echo "== 2. Configuration"
CFG="$DOCROOT/backend/config.php"
# value for a PHP '...' string, escaped once more for the sed replacement
sedv() { sq "$1" | sed 's/[\\#&]/\\&/g'; }
sed -i -e "s#'__SITENAME__'#'$(sedv "$SITENAME")'#" \
       -e "s#'__SITEEMAIL__'#'$(sedv "$SITEEMAIL")'#" \
       -e "s#'__SITEURL__'#'$(sedv "$SITEURL")'#" "$CFG"
MYSQL_PHP="$DOCROOT/backend/mysql.php"
cat > "$MYSQL_PHP" <<EOF
<?php
// Database connection - written by install.sh ($(date +%F))
\$mysql_host = "localhost";
\$mysql_user = '$(sq "$DBUSER")';
\$mysql_pass = '$(sq "$DBPASS")';
\$mysql_db   = '$(sq "$DBNAME")';
?>
EOF
# domain placeholder in the text files
grep -rlIF "__SITEDOMAIN__" "$DOCROOT" 2>/dev/null | while IFS= read -r f; do sed -i "s#__SITEDOMAIN__#$DOMAIN#g" "$f"; done
"$PHP" -l "$CFG" >/dev/null && "$PHP" -l "$MYSQL_PHP" >/dev/null || { echo "config.php / mysql.php syntax error."; exit 1; }

echo "== 3. Database"
if mysql -e "SELECT 1" >/dev/null 2>&1; then
  mysql -e "CREATE DATABASE IF NOT EXISTS \`$DBNAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
            CREATE USER IF NOT EXISTS '$(sq "$DBUSER")'@'localhost' IDENTIFIED BY '$(sq "$DBPASS")';
            ALTER USER '$(sq "$DBUSER")'@'localhost' IDENTIFIED BY '$(sq "$DBPASS")';
            GRANT ALL PRIVILEGES ON \`$DBNAME\`.* TO '$(sq "$DBUSER")'@'localhost'; FLUSH PRIVILEGES;" \
    || { echo "Creating the database / user failed (create them in the panel and run again)."; exit 1; }
  echo "   database and user ready"
else
  echo "   root has no MySQL access here - the database and user must already exist (e.g. made in the panel)"
fi
export MYSQL_PWD="$DBPASS"          # password for the mysql client (not visible in the process list)
MYSQL_U=(mysql -u "$DBUSER" "$DBNAME")
"${MYSQL_U[@]}" -e "SELECT 1" >/dev/null 2>&1 || { echo "Cannot log in to $DBNAME as $DBUSER."; exit 1; }
if [ "$("${MYSQL_U[@]}" -N -e "SHOW TABLES LIKE 'users'")" = "users" ]; then
  echo "   tables already exist - import skipped (empty the database to install again)"
else
  "${MYSQL_U[@]}" < "$HERE/database/schema.sql" || { echo "Importing the structure failed."; exit 1; }
  "${MYSQL_U[@]}" < "$HERE/database/data.sql"   || { echo "Importing the settings failed."; exit 1; }
  echo "   $("${MYSQL_U[@]}" -N -e "SHOW TABLES" | wc -l) tables imported"
fi

unset MYSQL_PWD
echo "== 4. Owner account"
TT_DBHOST=localhost TT_DBUSER="$DBUSER" TT_DBPASS="$DBPASS" TT_DBNAME="$DBNAME" \
TT_ADMIN_USER="$AUSER" TT_ADMIN_EMAIL="$AEMAIL" TT_ADMIN_PASS="$APASS" \
TT_ADMIN_CLASS="$OWNER_CLASS" TT_THEME="$DEFAULT_THEME" TT_LANG="$DEFAULT_LANGUAGE" \
  "$PHP" "$HERE/create_admin.php" || echo "   (account not created - see the message above)"

echo "== 5. Owner and rights"
chown -R "$OWNER:$GROUP" "$DOCROOT"
find "$DOCROOT" -type d -exec chmod 755 {} +
find "$DOCROOT" -type f -exec chmod 644 {} +
for d in avatars bbimages uploads uploads/images cache backups; do
  mkdir -p "$DOCROOT/$d"; chmod 775 "$DOCROOT/$d"
done
chmod 640 "$MYSQL_PHP"

echo
echo "== DONE"
echo "   Open:   $SITEURL  and log in as $AUSER"
echo "   Then in $CFG fill in (optional):"
echo "     OMDB_API_KEY, TMDB_API_KEY, YOUTUBE_API_KEY  - movie data / trailers"
echo "     CLOUDSITEKEY, CLOUDSECRET                    - Cloudflare Turnstile"
echo "     mail_smtp_user, mail_smtp_pass               - sending e-mail"
echo "   Keep this installer folder private (it is not needed any more)."
