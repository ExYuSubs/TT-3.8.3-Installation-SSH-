-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `blocks`
--

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (1,'donate','donate','left','Description here...',0,0);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (2,'invite','invite','right','Description here...',1,2);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (3,'Main Navigation','navigate','left','Description here...',1,4);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (4,'Login Block','login','left','Description here...',1,1);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (5,'rss','rss','right','Description here...',0,0);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (6,'latestuploads','latestuploads','right','Description here...',1,1);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (7,'advancestats','advancestats','left','Description here...',1,5);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (8,'serverload','serverload','right','Description here...',1,4);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (9,'usersonline','usersonline','right','Description here...',1,6);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (10,'Main Category','maincats','left','Description here...',1,3);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (11,'simplesearch','simplesearch','right','Description here...',1,5);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (12,'advancesearch','advancesearch','right','Description here...',0,0);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (13,'latestimages','latestimages','right','Description here...',0,0);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (14,'mostactivetorrents','mostactivetorrents','left','Description here...',0,0);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (15,'scrollingnews','scrollingnews','left','Description here...',0,0);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (16,'newestmember','newestmember','left','Description here...',0,0);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (17,'polls','polls','left','Description here...',1,6);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (18,'seedwanted','seedwanted','left','Description here...',0,0);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (19,'Theme & Language','themelang','left','Description here...',1,2);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (20,'Powered By','poweredby','right','Description here...',1,3);
INSERT INTO `blocks` (`id`, `named`, `name`, `position`, `description`, `enabled`, `sort`) VALUES (21,'latestforumpost','latestforumpost','middle','',0,1);
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:47
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (1,'720p',1,'','fa-tv','#ff8000','yes','Movies','1');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (2,'1080p',2,'','fa-tv','#00ff00','yes','Movies','2');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (3,'4K',3,'','fa-tv','','yes','Movies','3');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (5,'720p',5,'','fa-folder','#ff9900','yes','TV','5');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (6,'1080p',6,'','fa-folder','#f5c518','yes','TV','6');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (7,'4K',7,'','fa-folder','#ff6600','yes','TV','7');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (9,'All',9,'','fa-folder','','yes','Documentar','9');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (10,'PC',10,'','fa-folder','','yes','Games','10');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (11,'PS2',11,'','fa-folder','','yes','Games','11');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (12,'PSP',12,'','fa-folder','','yes','Games','12');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (13,'Xbox',13,'','fa-folder','','yes','Games','13');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (14,'Xbox360',14,'','fa-folder','','yes','Games','14');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (15,'PS1',15,'','fa-folder','','yes','Games','15');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (16,'Dreamcast',16,'','fa-folder','','yes','Games','16');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (17,'Other',20,'','fa-folder','','yes','Games','20');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (18,'PC',18,'','fa-folder','','yes','Apps','18');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (19,'Mac',19,'','fa-folder','','yes','Apps','19');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (20,'Linux',20,'','fa-folder','','yes','Apps','20');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (21,'Other',21,'','fa-folder','','yes','Apps','21');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (22,'MP3',22,'','fa-folder','','yes','Music','22');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (23,'Lossless',23,'','fa-folder','','yes','Music','23');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (24,'DVD',24,'','fa-folder','','yes','Music','24');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (25,'Video',25,'','fa-folder','','yes','Music','25');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (26,'Radio',26,'','fa-folder','','yes','Music','26');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (27,'Other',27,'','fa-folder','','yes','Music','27');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (28,'All',0,'','fa-folder','','yes','Anime','28');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (33,'Emulation',33,'','fa-folder','','yes','Other','33');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (34,'PPC/PDA',34,'','fa-folder','','yes','Other','34');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (35,'Sounds',35,'','fa-folder','','yes','Other','35');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (36,'E-Books',36,'','fa-folder','','yes','Other','36');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (37,'Images',37,'','fa-folder','','yes','Other','37');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (38,'Mobile Phone',38,'','fa-folder','','yes','Other','38');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (39,'Extra Pars/Fills',39,'','fa-folder','','yes','Other','39');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (40,'Other',40,'','fa-folder','','yes','Other','40');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (8,'HD',6,'','fa-folder','#ff9600','yes','TV','6');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (4,'HD',3,'','fa-folder','','yes','Movies','3');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (43,'PS3',12,'','fa-folder','','yes','Games','12');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (44,'Wii',17,'','fa-folder','','yes','Games','17');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (45,'DS',18,'','fa-folder','','yes','Games','18');
INSERT INTO `categories` (`id`, `name`, `sort_index`, `image`, `fa_icon`, `fa_color`, `subcat`, `parent_cat`, `sub_sort`) VALUES (46,'GameCube',19,'','fa-folder','','yes','Games','19');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:47
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `censor`
--

LOCK TABLES `censor` WRITE;
/*!40000 ALTER TABLE `censor` DISABLE KEYS */;
INSERT INTO `censor` (`word`, `censor`) VALUES ('fuck','f**k');
/*!40000 ALTER TABLE `censor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:47
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (1,'Sweden','SE');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (2,'United States of America','US');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (3,'Russia','RU');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (4,'Finland','FI');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (5,'Canada','CA');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (6,'France','FR');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (7,'Germany','DE');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (8,'China','CN');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (9,'Italy','IT');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (10,'Denmark','DK');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (11,'Norway','NO');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (12,'United Kingdom','UK');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (13,'Ireland','IE');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (14,'Poland','PL');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (15,'Netherlands','NL');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (16,'Belgium','BE');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (17,'Japan','JP');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (18,'Brazil','BR');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (19,'Argentina','AR');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (20,'Australia','AU');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (21,'New Zealand','NZ');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (23,'Spain','ES');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (24,'Portugal','PT');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (25,'Mexico','MX');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (26,'Singapore','SG');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (29,'South Africa','ZA');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (30,'South Korea','KR');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (31,'Jamaica','JM');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (32,'Luxembourg','LU');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (33,'Hong Kong','HK');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (34,'Belize','BZ');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (35,'Algeria','DZ');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (36,'Angola','AO');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (37,'Austria','AT');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (38,'Bosnia and Hercegovina','BA');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (39,'Western Samoa','WS');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (40,'Malaysia','MY');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (41,'Dominican Republic','DO');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (42,'Greece','GR');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (43,'Guatemala','GT');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (44,'Israel','IL');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (45,'Pakistan','PK');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (46,'Czech Republic','CZ');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (47,'Serbia','YU');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (48,'Seychelles','SC');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (49,'Taiwan','TW');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (50,'Puerto Rico','PR');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (51,'Chile','CL');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (52,'Cuba','CU');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (53,'Congo','CG');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (54,'Afghanistan','AF');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (55,'Turkey','TR');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (56,'Uzbekistan','UZ');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (57,'Switzerland','CH');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (58,'Kiribati','KI');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (59,'Philippines','PH');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (60,'Burkina Faso','BF');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (61,'Nigeria','NG');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (62,'Iceland','IS');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (63,'Nauru','NR');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (64,'Slovenia','SI');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (65,'Albania','AL');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (66,'Turkmenistan','TM');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (67,'Bosnia Herzegovina','BA');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (68,'Andorra','AD');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (69,'Lithuania','LT');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (70,'India','IN');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (71,'Netherlands Antilles','AN');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (72,'Ukraine','UA');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (73,'Venezuela','VE');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (74,'Hungary','HU');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (75,'Romania','RO');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (76,'Vanuatu','VU');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (77,'Vietnam','VN');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (78,'Trinidad &amp; Tobago','TT');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (79,'Honduras','HN');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (80,'Kyrgyzstan','KG');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (81,'Ecuador','EC');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (82,'Bahamas','BS');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (83,'Peru','PE');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (84,'Cambodia','KH');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (85,'Barbados','BB');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (86,'Bangladesh','BD');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (87,'Laos','LA');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (88,'Uruguay','UY');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (89,'Antigua Barbuda','AG');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (90,'Paraguay','PY');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (92,'Union of Soviet Socialist Republics','SU');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (93,'Thailand','TH');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (94,'Senegal','SN');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (95,'Togo','TG');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (96,'North Korea','KP');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (97,'Croatia','HR');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (98,'Estonia','EE');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (99,'Colombia','CO');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (100,'England','GB');
INSERT INTO `countries` (`id`, `name`, `domain`) VALUES (101,'Egypt','EG');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:47
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `external_trackers`
--

LOCK TABLES `external_trackers` WRITE;
/*!40000 ALTER TABLE `external_trackers` DISABLE KEYS */;
INSERT INTO `external_trackers` (`id`, `url`, `recommended`, `sort_index`, `enabled`) VALUES (1,'http://bt1.archive.org:6969/announce',1,1,1);
INSERT INTO `external_trackers` (`id`, `url`, `recommended`, `sort_index`, `enabled`) VALUES (2,'udp://tracker.opentrackr.org:1337/announce',1,2,1);
INSERT INTO `external_trackers` (`id`, `url`, `recommended`, `sort_index`, `enabled`) VALUES (3,'udp://tracker.torrent.eu.org:451/announce',0,3,1);
INSERT INTO `external_trackers` (`id`, `url`, `recommended`, `sort_index`, `enabled`) VALUES (4,'udp://exodus.desync.com:6969/announce',0,4,1);
INSERT INTO `external_trackers` (`id`, `url`, `recommended`, `sort_index`, `enabled`) VALUES (5,'udp://opentracker.io:6969/announce',0,5,1);
INSERT INTO `external_trackers` (`id`, `url`, `recommended`, `sort_index`, `enabled`) VALUES (6,'http://bt2.archive.org:6969/announce',1,6,1);
INSERT INTO `external_trackers` (`id`, `url`, `recommended`, `sort_index`, `enabled`) VALUES (7,'udp://open.stealth.si:80/announce',0,7,1);
INSERT INTO `external_trackers` (`id`, `url`, `recommended`, `sort_index`, `enabled`) VALUES (8,'udp://tracker.dler.org:6969/announce',0,8,1);
INSERT INTO `external_trackers` (`id`, `url`, `recommended`, `sort_index`, `enabled`) VALUES (9,'udp://d40969.acod.regrucolo.ru:6969/announce',0,9,1);
/*!40000 ALTER TABLE `external_trackers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:47
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (1,'categ','Site information','','1',0,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (2,'categ','User information','','1',0,2);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (3,'categ','Stats','','1',0,3);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (4,'categ','Uploading','','1',0,4);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (5,'categ','Downloading','','1',0,5);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (6,'categ','How can I improve my download speed?','','1',0,6);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (7,'categ','My ISP uses a transparent proxy. What should I do?','','1',0,7);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (8,'categ','Why can\'t I connect? Is the site blocking me?','','1',0,8);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (9,'categ','What if I can\'t find the answer to my problem here?','','1',0,9);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (10,'item','What is this bittorrent all about anyway? How do I get the files?','Check out <a href=\"http://www.btfaq.com/\">Brian\'s BitTorrent FAQ and Guide</a>','1',1,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (13,'item','I registered an account but did not receive the confirmation e-mail!','You can use <a href=\"account-delete.php\">this form</a> to delete the account so you can re-register.\r\nNote though that if you didn\'t receive the email the first time it will probably not\r\nsucceed the second time either so you should really try another email address.','1',2,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (14,'item','I\'ve lost my user name or password! Can you send it to me?','Please use <a href=\"account-recover.php\">this form</a> to have the login details mailed back to you.','1',2,2);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (16,'item','Can you delete my account?','You cannot delete your own account, please ask a member of staff','1',2,4);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (17,'item','So, what\'s MY ratio?','Click on your <a href=\"account.php\">profile</a>, then on your user name (at the top).<br />\r\n<br />\r\nIt\'s important to distinguish between your overall ratio and the individual ratio on each torrent\r\nyou may be seeding or leeching. The overall ratio takes into account the total uploaded and downloaded\r\nfrom your account since you joined the site. The individual ratio takes into account those values for each torrent.<br />\r\n<br />\r\nYou may see two symbols instead of a number: &quot;Inf.&quot;, which is just an abbreviation for Infinity, and\r\nmeans that you have downloaded 0 bytes while uploading a non-zero amount (ul/dl becomes infinity); &quot;---&quot;,\r\nwhich should be read as &quot;non-available&quot;, and shows up when you have both downloaded and uploaded 0 bytes\r\n(ul/dl = 0/0 which is an indeterminate amount).','1',2,5);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (18,'item','Why is my IP displayed on my details page?','Only you and the site moderators can view your IP address and email. Regular users do not see that information.','1',2,6);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (19,'item','Help! I cannot login!?','This problem sometimes occurs with MSIE. Close all Internet Explorer windows and open Internet Options in the control panel. Click the Delete Cookies button. You should now be able to login.\r\n','1',2,7);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (20,'item','My IP address is dynamic. How do I stay logged in?','You do not have to anymore. All you have to do is make sure you are logged in with your actual\r\nIP when starting a torrent session. After that, even if the IP changes mid-session,\r\nthe seeding or leeching will continue and the statistics will update without any problem.','1',2,8);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (21,'item','Why is my port number reported as \"---\"? (And why should I care?)','The tracker has determined that you are firewalled or NATed and cannot accept incoming connections.\r\n<br />\r\n<br />\r\nThis means that other peers in the swarm will be unable to connect to you, only you to them. Even worse,\r\nif two peers are both in this state they will not be able to connect at all. This has obviously a\r\ndetrimental effect on the overall speed.\r\n<br />\r\n<br />\r\nThe way to solve the problem involves opening the ports used for incoming connections\r\n(the same range you defined in your client) on the firewall and/or configuring your\r\nNAT server to use a basic form of NAT\r\nfor that range instead of NAPT (the actual process differs widely between different router models.\r\nCheck your router documentation and/or support forum. You will also find lots of information on the\r\nsubject at <a href=\"http://portforward.com/\">PortForward</a>).','1',2,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (27,'item','Most common reason for stats not updating','<ul>\r\n<li>The user is cheating. (a.k.a. &quot;Summary Ban&quot;)</li>\r\n<li>The server is overloaded and unresponsive. Just try to keep the session open until the server responds again. (Flooding the server with consecutive manual updates is not recommended.)</li>\r\n</ul>','1',3,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (28,'item','Best practices','<ul>\r\n<li>If a torrent you are currently leeching/seeding is not listed on your profile, just wait or force a manual update.</li>\r\n<li>Make sure you exit your client properly, so that the tracker receives &quot;event=completed&quot;.</li>\r\n<li>If the tracker is down, do not stop seeding. As long as the tracker is back up before you exit the client the stats should update properly.</li>\r\n</ul>','1',3,2);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (29,'item','May I use any bittorrent client?','Yes. The tracker now updates the stats correctly for all bittorrent clients. However, we still recommend\r\nthat you <b>avoid</b> the following clients:<br />\r\n<br />\r\n\r\n<ul>\r\n<li>BitTorrent++</li>\r\n<li>Nova Torrent</li>\r\n<li>TorrentStorm</li>\r\n</ul>\r\n\r\n<br />\r\nThese clients do not report correctly to the tracker when canceling/finishing a torrent session.\r\nIf you use them then a few MB may not be counted towards\r\nthe stats near the end, and torrents may still be listed in your profile for some time after you have closed the client.<br />\r\n<br />\r\nAlso, clients in alpha or beta version should be avoided.','1',3,3);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (30,'item','Why is a torrent I\'m leeching/seeding listed several times in my profile?','If for some reason (e.g. pc crash, or frozen client) your client exits improperly and you restart it,\r\nit will have a new peer_id, so it will show as a new torrent. The old one will never receive a &quot;event=completed&quot;\r\nor &quot;event=stopped&quot; and will be listed until some tracker timeout. Just ignore it, it will eventually go away.','1',3,4);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (31,'item','I\'ve finished or cancelled a torrent. Why is it still listed in my profile?','Some clients, notably TorrentStorm and Nova Torrent, do not report properly to the tracker when canceling or finishing a torrent.\r\nIn that case the tracker will keep waiting for some message - and thus listing the torrent as seeding or leeching - until some\r\ntimeout occurs. Just ignore it, it will eventually go away.','1',3,5);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (32,'item','Why do I sometimes see torrents I\'m not leeching in my profile!?','When a torrent is first started, the tracker uses the IP to identify the user. Therefore the torrent will\r\nbecome associated with the user <i>who last accessed the site</i> from that IP. If you share your IP in some\r\nway (you are behind NAT/ICS, or using a proxy), and some of the persons you share it with are also users,\r\nyou may occasionally see their torrents listed in your profile. (If they start a torrent session from that\r\nIP and you were the last one to visit the site the torrent will be associated with you). Note that now\r\ntorrents listed in your profile will always count towards your total stats.','2',3,6);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (34,'item','How does NAT/ICS change the picture?','This is a very particular case in that all computers in the LAN will appear to the outside world as having the same IP. We must distinguish\r\nbetween two cases:<br />\r\n<br />\r\n<b>1.</b> <i>You are the single  user in the LAN</i><br />\r\n<br />\r\nYou should use the same account in all the computers.<br />\r\n<br />\r\nNote also that in the ICS case it is preferable to run the BT client on the ICS gateway. Clients running on the other computers\r\nwill be unconnectable (their ports will be listed as &quot;---&quot;, as explained elsewhere in the FAQ) unless you specify\r\nthe appropriate services in your ICS configuration (a good explanation of how to do this for Windows XP can be found\r\n<a href=\"http://www.microsoft.com/downloads/details.aspx?FamilyID=1dcff3ce-f50f-4a34-ae67-cac31ccd7bc9&amp;displaylang=en\">here</a>).\r\nIn the NAT case you should configure different ranges for clients on different computers and create appropriate NAT rules in the router. (Details vary widely from router to router and are outside the scope of this FAQ. Check your router documentation and/or support forum.)<br />\r\n<br />\r\n<br />\r\n<b>2.</b> <i>There are multiple users in the LAN</i><br />\r\n<br />\r\nAt present there is no way of making this setup always work properly.\r\nEach torrent will be associated with the user who last accessed the site from within\r\nthe LAN before the torrent was started.\r\nUnless there is cooperation between the users mixing of statistics is possible.\r\n(User A accesses the site, downloads a .torrent file, but does not start the torrent immediately.\r\nMeanwhile, user B accesses the site. User A then starts the torrent. The torrent will count\r\ntowards user B\'s statistics, not user A\'s.)\r\n<br />\r\n<br />\r\nIt is your LAN, the responsibility is yours. Do not ask us to ban other users\r\nwith the same IP, we will not do that. (Why should we ban <i>him</i> instead of <i>you</i>?)','1',3,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (36,'item','Why can\'t I upload torrents?','Only specially authorized users (<font color=\"#4040c0\"><b>Uploaders</b></font>) have permission to upload torrents.','1',4,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (37,'item','What criteria must I meet before I can join the <font color=\"#4040c0\">Uploader</font> team?','You must be able to provide releases that:<br />\r\n<ul>\r\n<li>include a proper NFO</li>\r\n<li>are genuine scene releases. If it\'s not on <a href=\"http://www.nforce.nl\">NFOrce</a> then forget it! (except music).</li>\r\n<li>are not older than seven (7) days.</li>\r\n<li>have all files in original format (usually 14.3 MB RARs)</li>\r\n<li>you\'ll be able to seed, or make sure are well-seeded, for at least 24 hours.</li>\r\n<li>you should have atleast 2MBit upload bandwith.</li>\r\n</ul>\r\n\r\n<br />\r\nIf you think you can match these criteria do not hesitate to <a href=\"staff.php\">contact</a> one of the administrators.<br />\r\n<b>Remember!</b> Write your application carefully! Be sure to include your UL speed and what kind of stuff you\'re planning to upload.<br />\r\nOnly well written letters with serious intent will be considered.','1',4,2);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (39,'item','How do I use the files I\'ve downloaded?','Check out <a href=\"videoformats.php\">this guide</a>.','1',5,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (40,'item','Downloaded a movie and don\'t know what CAM/TS/TC/SCR means?','Check out <a href=\"videoformats.php\">this guide.</a>','1',5,2);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (41,'item','Why did an active torrent suddenly disappear?','There may be three reasons for this:<br />\r\n(<b>1</b>) The torrent may have been out-of-sync with the site\r\n<a href=\"rules.php\">rules</a>.<br />\r\n(<b>2</b>) The uploader may have deleted it because it was a bad release.\r\nA replacement will probably be uploaded to take its place.<br />\r\n(<b>3</b>) Torrents are automatically deleted after 28 days.','2',5,3);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (42,'item','How do I resume a broken download or reseed something?','Open the .torrent file. When your client asks you for a location, choose the location of the existing file(s) and it will resume/reseed the torrent.\r\n','1',5,4);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (43,'item','Why do my downloads sometimes stall at 99%?','The more pieces you have, the harder it becomes to find peers who have pieces you are missing. That is why downloads sometimes slow down or even stall when there are just a few percent remaining. Just be patient and you will, sooner or later, get the remaining pieces.\r\n','1',5,5);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (44,'item','What are these \"a piece has failed an hash check\" messages?','Bittorrent clients check the data they receive for integrity. When a piece fails this check it is\r\nautomatically re-downloaded. Occasional hash fails are a common occurrence, and you shouldn\'t worry.<br />\r\n<br />\r\nSome clients have an (advanced) option/preference to \'kick/ban clients that send you bad data\' or\r\nsimilar. It should be turned on, since it makes sure that if a peer repeatedly sends you pieces that\r\nfail the hash check it will be ignored in the future.','1',5,6);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (45,'item','The torrent is supposed to be 100MB. How come I downloaded 120MB?','See the hash fails topic. If your client receives bad data it will have to redownload it, therefore\r\nthe total downloaded may be larger than the torrent size. Make sure the &quot;kick/ban&quot; option is turned on\r\nto minimize the extra downloads.','1',5,7);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (46,'item','Why do I get a \"Not authorized (xx h) - READ THE FAQ\" error?','From the time that each <b>new</b> torrent is uploaded to the tracker, there is a period of time that\r\nsome users must wait before they can download it.<br />\r\nThis delay in downloading will only affect users with a low ratio, and users with low upload amounts.<br />\r\n<br />\r\n<table class=\"table_table\" cellspacing=\"3\" cellpadding=\"5\" align=\"center\">\r\n <tr>\r\n    <td class=\"table_col1\"><b>Ratio below</b></td>\r\n    <td class=\"table_col2\" align=\"center\"><font color=\"#bb0000\">0.50</font></td>\r\n    <td class=\"table_col2\">and/or upload below</td>\r\n    <td class=\"table_col1\" align=\"center\">5.0GB</td>\r\n    <td class=\"table_col2\">delay of</td>\r\n    <td class=\"table_col1\" align=\"center\">48h</td>\r\n </tr>\r\n <tr>\r\n    <td class=\"table_col1\"><b>Ratio below</b></td>\r\n    <td class=\"table_col2\"><font color=\"#A10000\">0.65</font></td>\r\n    <td class=\"table_col1\">and/or upload below</td>\r\n    <td class=\"table_col2\">6.5GB</td>\r\n    <td class=\"table_col1\">delay of</td>\r\n    <td class=\"table_col2\">24h</td>\r\n </tr>\r\n <tr>\r\n    <td class=\"table_col1\"><b>Ratio below</b></td>\r\n    <td class=\"table_col2\"><font color=\"#880000\">0.80</font></td>\r\n    <td class=\"table_col1\">and/or upload below</td>\r\n    <td class=\"table_col2\">8.0GB</td>\r\n    <td class=\"table_col1\">delay of</td>\r\n    <td class=\"table_col2\">12h</td>\r\n </tr>\r\n <tr>\r\n    <td class=\"table_col1\"><b>Ratio below</b></td>\r\n    <td class=\"table_col2\"><font color=\"#6E0000\">0.95</font></td>\r\n    <td class=\"table_col1\">and/or upload below</td>\r\n    <td class=\"table_col2\">9.5GB</td>\r\n    <td class=\"table_col1\">delay of</td>\r\n    <td class=\"table_col2\">06h</td>\r\n </tr>\r\n</table>\r\n<br />\r\n\"<b>And/or</b>\" means any or both. Your delay will be the <b>largest</b> one for which you meet <b>at least</b> one condition.<br />\r\n<br />\r\nThis applies to new users as well, so opening a new account will not help. Note also that this\r\nworks at tracker level, you will be able to grab the .torrent file itself at any time.<br />\r\n<br />\r\n<!--The delay applies only to leeching, not to seeding. If you got the files from any other source and\r\nwish to seed them you may do so at any time irrespectively of your ratio or total uploaded.<br />-->\r\nN.B. Due to some users exploiting the \'no-delay-for-seeders\' policy we had to change it. The delay\r\nnow applies to both seeding and leeching. So if you are subject to a delay and get the files from\r\nsome other source you will not be able to seed them until the delay has elapsed.','3',5,8);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (47,'item','Why do I get a \"rejected by tracker - Port xxxx is blacklisted\" error?','Your client is reporting to the tracker that it uses one of the default bittorrent ports\r\n(6881-6889) or any other common p2p port for incoming connections.<br />\r\n<br />\r\nThis tracker does not allow clients to use ports commonly associated with p2p protocols.\r\nThe reason for this is that it is a common practice for ISPs to throttle those ports\r\n(that is, limit the bandwidth, hence the speed). <br />\r\n<br />\r\nThe blocked ports list include, but is not neccessarily limited to, the following:<br />\r\n<br />\r\n  <table border=\"0\" cellspacing=\"3\" cellpadding=\"5\" class=\"table_table\" align=\"center\">\r\n  <tr>\r\n    <td class=\"table_col1\"><b>Direct Connect</b></td>\r\n    <td class=\"table_col2\">411 - 413</td>\r\n  </tr>\r\n  <tr>\r\n    <td class=\"table_col1\"><b>Kazaa</b></td>\r\n    <td class=\"table_col2\">1214</td>\r\n  </tr>\r\n  <tr>\r\n    <td class=\"table_col1\"><b>eDonkey</b></td>\r\n    <td class=\"table_col2\">4662</td>\r\n  </tr>\r\n  <tr>\r\n    <td class=\"table_col1\"><b>Gnutella</b></td>\r\n    <td class=\"table_col2\">6346 - 6347</td>\r\n  </tr>\r\n  <tr>\r\n    <td class=\"table_col1\"><b>BitTorrent</b></td>\r\n    <td class=\"table_col2\">6881 - 6889</td>\r\n </tr>\r\n</table>\r\n<br />\r\nIn order to use use our tracker you must  configure your client to use\r\nany port range that does not contain those ports (a range within the region 49152 through 65535 is preferable,\r\ncf. <a href=\"http://www.iana.org/assignments/port-numbers\">IANA</a>). Notice that some clients,\r\nlike Azureus 2.0.7.0 or higher, use a single port for all torrents, while most others use one port per open torrent. The size\r\nof the range you choose should take this into account (typically less than 10 ports wide. There\r\nis no benefit whatsoever in choosing a wide range, and there are possible security implications). <br />\r\n<br />\r\nThese ports are used for connections between peers, not client to tracker.\r\nTherefore this change will not interfere with your ability to use other trackers (in fact it\r\nshould <i>increase</i> your speed with torrents from any tracker, not just ours). Your client\r\nwill also still be able to connect to peers that are using the standard ports.\r\nIf your client does not allow custom ports to be used, you will have to switch to one that does.<br />\r\n<br />\r\nDo not ask us, or in the forums, which ports you should choose. The more random the choice is the harder\r\nit will be for ISPs to catch on to us and start limiting speeds on the ports we use.\r\nIf we simply define another range ISPs will start throttling that range also. <br />\r\n<br />\r\nFinally, remember to forward the chosen ports in your router and/or open them in your\r\nfirewall, should you have them.','3',5,9);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (48,'item','What\'s this \"IOError - [Errno13] Permission denied\" error?','If you just want to fix it reboot your computer, it should solve the problem.\r\nOtherwise read on.<br />\r\n<br />\r\nIOError means Input-Output Error, and that is a file system error, not a tracker one.\r\nIt shows up when your client is for some reason unable to open the partially downloaded\r\ntorrent files. The most common cause is two instances of the client to be running\r\nsimultaneously:\r\nthe last time the client was closed it somehow didn\'t really close but kept running in the\r\nbackground, and is therefore still\r\nlocking the files, making it impossible for the new instance to open them.<br />\r\n<br />\r\nA more uncommon occurrence is a corrupted FAT. A crash may result in corruption\r\nthat makes the partially downloaded files unreadable, and the error ensues. Running\r\nscandisk should solve the problem. (Note that this may happen only if you\'re running\r\nWindows 9x - which only support FAT - or NT/2000/XP with FAT formatted hard drives.\r\nNTFS is much more robust and should never permit this problem.)','3',5,10);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (49,'item','What\'s this \"TTL\" in the browse page?','The torrent\'s Time To Live, in hours. It means the torrent will be deleted\r\nfrom the tracker after that many hours have elapsed (yes, even if it is still active).\r\nNote that this a maximum value, the torrent may be deleted at any time if it\'s inactive.','3',5,11);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (50,'item','Do not immediately jump on new torrents','The download speed mostly depends on the seeder-to-leecher ratio (SLR). Poor download speed is\r\nmainly a problem with new and very popular torrents where the SLR is low.<br />\r\n<br />\r\n(Proselytising sidenote: make sure you remember that you did not enjoy the low speed.\r\n<b>Seed</b> so that others will not endure the same.)<br />\r\n<br />\r\nThere are a couple of things that you can try on your end to improve your speed:<br />\r\n<br />In particular, do not do it if you have a slow connection. The best speeds will be found around the\r\nhalf-life of a torrent, when the SLR will be at its highest. (The downside is that you will not be able to seed\r\nso much. It\'s up to you to balance the pros and cons of this.)','1',6,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (51,'item','Limit your upload speed','The upload speed affects the download speed in essentially two ways:<br />\r\n<ul>\r\n    <li>Bittorrent peers tend to favour those other peers that upload to them. This means that if A and B\r\n    are leeching the same torrent and A is sending data to B at high speed then B will try to reciprocate.\r\n    So due to this effect high upload speeds lead to high download speeds.</li>\r\n\r\n    <li>Due to the way TCP works, when A is downloading something from B it has to keep telling B that\r\n        it received the data sent to him. (These are called acknowledgements - ACKs -, a sort of &quot;got it!&quot; messages).\r\n        If A fails to do this then B will stop sending data and wait. If A is uploading at full speed there may be no\r\n        bandwidth left for the ACKs and they will be delayed. So due to this effect excessively high upload speeds lead\r\n        to low download speeds.</li>\r\n</ul>\r\n\r\nThe full effect is a combination of the two. The upload should be kept as high as possible while allowing the\r\nACKs to get through without delay. <b>A good thumb rule is keeping the upload at about 80% of the theoretical\r\nupload speed.</b> You will have to fine tune yours to find out what works best for you. (Remember that keeping the\r\nupload high has the additional benefit of helping with your ratio.) <br />\r\n<br />\r\nIf you are running more than one instance of a client it is the overall upload speed that you must take into account.\r\nSome clients (e.g. Azureus) limit global upload speed, others (e.g. Shad0w\'s) do it on a per torrent basis.\r\nKnow your client. The same applies if you are using your connection for anything else (e.g. browsing or ftp),\r\nalways think of the overall upload speed.','1',6,2);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (52,'item','Limit the number of simultaneous connections','Some operating systems (like Windows 9x) do not deal well with a large number of connections, and may even crash.\r\nAlso some home routers (particularly when running NAT and/or firewall with stateful inspection services) tend to become\r\nslow or crash when having to deal with too many connections. There are no fixed values for this, you may try 60 or 100\r\nand experiment with the value. Note that these numbers are additive, if you have two instances of\r\na client running the numbers add up.','1',6,3);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (53,'item','Limit the number of simultaneous uploads','Isn\'t this the same as above? No. Connections limit the number of peers your client is talking to and/or\r\ndownloading from. Uploads limit the number of peers your client is actually uploading to. The ideal number is\r\ntypically much lower than the number of connections, and highly dependent on your (physical) connection.','1',6,4);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (54,'item','Just give it some time','As explained above peers favour other peers that upload to them. When you start leeching a new torrent you have\r\nnothing to offer to other peers and they will tend to ignore you. This makes the starts slow, in particular if,\r\nby change, the peers you are connected to include few or no seeders. The download speed should increase as soon\r\nas you have some pieces to share.','1',6,5);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (55,'item','Why is my browsing so slow while leeching?','Your download speed is always finite. If you are a peer in a fast torrent it will almost certainly saturate your\r\ndownload bandwidth, and your browsing will suffer. At the moment there is no client that allows you to limit the\r\ndownload speed, only the upload. You will have to use a third-party solution,\r\nsuch as <a href=\"http://www.netlimiter.com/\">NetLimiter</a>.<br />\r\n<br />\r\nBrowsing was used just as an example, the same would apply to gaming, IMing, etc...','1',6,6);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (56,'item','What is a proxy?','Basically a middleman. When you are browsing a site through a proxy your requests are sent to the proxy and the proxy\r\nforwards them to the site instead of you connecting directly to the site. There are several classifications\r\n(the terminology is far from standard):<br />\r\n<br />\r\n\r\n\r\n<table cellspacing=\"3\" cellpadding=\"3\" class=\"table_table\" align=\"center\">\r\n <tr>\r\n    <td class=\"table_col1\"><b>Transparent</b></td>\r\n    <td class=\"table_col2\">A transparent proxy is one that needs no configuration on the clients. It works by automatically redirecting all port 80 traffic to the proxy. (Sometimes used as synonymous for non-anonymous.)</td>\r\n </tr>\r\n <tr>\r\n    <td class=\"table_col1\"><b>Explicit/Voluntary</b></td>\r\n    <td class=\"table_col2\">Clients must configure their browsers to use them.</td>\r\n </tr>\r\n <tr>\r\n    <td class=\"table_col1\"><b>Anonymous</b></td>\r\n    <td class=\"table_col2\">The proxy sends no client identification to the server. (HTTP_X_FORWARDED_FOR header is not sent; the server does not see your IP.)</td>\r\n </tr>\r\n <tr>\r\n    <td class=\"table_col1\"><b>Highly Anonymous</b></td>\r\n    <td class=\"table_col2\">The proxy sends no client nor proxy identification to the server. (HTTP_X_FORWARDED_FOR, HTTP_VIA and HTTP_PROXY_CONNECTION headers are not sent; the server doesn\'t see your IP and doesn\'t even know you\'re using a proxy.)</td>\r\n </tr>\r\n <tr>\r\n    <td class=\"table_col1\"><b>Public</b></td>\r\n    <td class=\"table_col2\">(Self explanatory)</td>\r\n </tr>\r\n</table>\r\n<br />\r\nA transparent proxy may or may not be anonymous, and there are several levels of anonymity.','1',7,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (57,'item','How do I find out if I\'m behind a (transparent/anonymous) proxy?','Try <a href=\"http://proxyjudge.org\">ProxyJudge</a>. It lists the HTTP headers that the server where it is running\r\nreceived from you. The relevant ones are HTTP_CLIENT_IP, HTTP_X_FORWARDED_FOR and REMOTE_ADDR.<br />\r\n<br />\r\n<br />\r\n<b>Why is my port listed as &quot;---&quot; even though I\'m not NAT/Firewalled?</b><a name=\"prox3\"></a><br />\r\n<br />\r\nThe tracker is quite smart at finding your real IP, but it does need the proxy to send the HTTP header\r\nHTTP_X_FORWARDED_FOR. If your ISP\'s proxy does not then what happens is that the tracker will interpret the proxy\'s IP\r\naddress as the client\'s IP address. So when you login and the tracker tries to connect to your client to see if you are\r\nNAT/firewalled it will actually try to connect to the proxy on the port your client reports to be using for\r\nincoming connections. Naturally the proxy will not be listening on that port, the connection will fail and the\r\ntracker will think you are NAT/firewalled.','1',7,2);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (58,'item','Can I bypass my ISP\'s proxy?','If your ISP only allows HTTP traffic through port 80 or blocks the usual proxy ports then you would need to use something\r\nlike <a href=\"http://www.socks.permeo.com\">socks</a> and that is outside the scope of this FAQ.<br />\r\n<br />\r\nOtherwise you may try the following:<br />\r\n<ul>\r\n    <li>Choose any public <b>non-anonymous</b> proxy that does <b>not</b> use port 80\r\n    (e.g. from <a href=\"http://tools.rosinstrument.com/proxy\">this</a>,\r\n    <a href=\"http://www.proxy4free.com/index.html\">this</a> or\r\n    <a href=\"http://www.samair.ru/proxy\">this</a> list).</li>\r\n\r\n    <li>Configure your computer to use that proxy. For Windows XP, do <i>Start</i>, <i>Control Panel</i>, <i>Internet Options</i>,\r\n    <i>Connections</i>, <i>LAN Settings</i>, <i>Use a Proxy server</i>, <i>Advanced</i> and type in the IP and port of your chosen\r\n    proxy. Or from Internet Explorer use <i>Tools</i>, <i>Internet Options</i>, ...<br /></li>\r\n\r\n    <li>(Facultative) Visit <a href=\"http://proxyjudge.org\">ProxyJudge</a>. If you see an HTTP_X_FORWARDED_FOR in\r\n    the list followed by your IP then everything should be ok, otherwise choose another proxy and try again.<br /></li>\r\n\r\n    <li>Visit this site. Hopefully the tracker will now pickup your real IP (check your profile to make sure).</li>\r\n</ul>\r\n<br />\r\nNotice that now you will be doing all your browsing through a public proxy, which are typically quite slow.\r\nCommunications between peers do not use port 80 so their speed will not be affected by this, and should be better than when\r\nyou were &quot;unconnectable&quot;.','1',7,3);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (59,'item','How do I make my bittorrent client use a proxy?','Just configure Windows XP as above. When you configure a proxy for Internet Explorer you\r\nre actually configuring a proxy for\r\nall HTTP traffic (thank Microsoft and their &quot;IE as part of the OS policy&quot; ). On the other hand if you use another\r\nbrowser (Opera/Mozilla/Firefox) and configure a proxy there you\'ll be configuring a proxy just for that browser. We don\'t\r\nknow of any BT client that allows a proxy to be specified explicitly.','1',7,4);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (60,'item','Why can\'t I signup from behind a proxy?','It is our policy not to allow new accounts to be opened from behind a proxy.','1',7,5);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (62,'item','Maybe my address is blacklisted?','The site blocks addresses listed in the (former) <a href=\"http://methlabs.org/\">PeerGuardian</a>\r\ndatabase, as well as addresses of banned users. This works at Apache/PHP level, it\'s just a script that\r\nblocks <i>logins</i> from those addresses. It should not stop you from reaching the site. In particular\r\nit does not block lower level protocols, you should be able to ping/traceroute the server even if your\r\naddress is blacklisted. If you cannot then the reason for the problem lies elsewhere.<br />\r\n<br />\r\nIf somehow your address is indeed blocked in the PG database do not contact us about it, it is not our\r\npolicy to open <i>ad hoc</i> exceptions. You should clear your IP with the database maintainers instead.','1',8,1);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (63,'item','Your ISP blocks the site\'s address','(In first place, it\'s unlikely your ISP is doing so. DNS name resolution and/or network problems are the usual culprits.)\r\n<br />\r\nThere\'s nothing we can do.\r\nYou should contact your ISP (or get a new one). Note that you can still visit the site via a proxy, follow the instructions\r\nin the relevant section. In this case it doesn\'t matter if the proxy is anonymous or not, or which port it listens to.<br />\r\n<br />\r\nNotice that you will always be listed as an &quot;unconnectable&quot; client because the tracker will be unable to\r\ncheck that you\'re capable of accepting incoming connections.','1',8,2);
INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES (65,'item','You can try these:','Post in the <a href=\"forums.php\">Forums</a>, by all means. You\'ll find they\r\nare usually a friendly and helpful place,\r\nprovided you follow a few basic guidelines:\r\n<ul>\r\n<li>Make sure your problem is not really in this FAQ. There\'s no point in posting just to be sent\r\nback here.</li>\r\n<li>Before posting read the sticky topics (the ones at the top). Many times new information that\r\nstill hasn\'t been incorporated in the FAQ can be found there.</li>\r\n<li>Help us in helping you. Do not just say \"it doesn\'t work!\". Provide details so that we don\'t\r\nhave to guess or waste time asking. What client do you use? What\'s your OS? What\'s your network setup? What\'s the exact\r\nerror message you get, if any? What are the torrents you are having problems with? The more\r\nyou tell the easiest it will be for us, and the more probable your post will get a reply.</li>\r\n<li>And needless to say: be polite. Demanding help rarely works, asking for it usually does\r\nthe trick.</li></ul>','1',9,1);
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:47
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `forumcats`
--

LOCK TABLES `forumcats` WRITE;
/*!40000 ALTER TABLE `forumcats` DISABLE KEYS */;
INSERT INTO `forumcats` (`id`, `name`, `sort`) VALUES (1,'Primary Forum',0);
/*!40000 ALTER TABLE `forumcats` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:47
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `forum_forums`
--

LOCK TABLES `forum_forums` WRITE;
/*!40000 ALTER TABLE `forum_forums` DISABLE KEYS */;
INSERT INTO `forum_forums` (`sort`, `id`, `name`, `description`, `minclassread`, `minclasswrite`, `guest_read`, `category`) VALUES (0,1,'First forum','Our first forum',1,1,'yes',1);
INSERT INTO `forum_forums` (`sort`, `id`, `name`, `description`, `minclassread`, `minclasswrite`, `guest_read`, `category`) VALUES (0,2,'Bugs','Report errors in the source code or bugs on the site',2,2,'no',1);
/*!40000 ALTER TABLE `forum_forums` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:48
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (1,'Watcher','#A0A0A0','no','no','no','no','no','no','no','no','no','no','no','yes','no','no','no','no','no',11,'no','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (2,'User','#0094FF','yes','no','no','no','no','no','yes','no','no','yes','yes','yes','no','no','no','no','no',10,'yes','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (4,'VIP','#EBEF00','yes','no','no','yes','no','no','yes','no','no','yes','yes','yes','no','no','no','yes','no',8,'yes','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (5,'Uploader','#00A49E','yes','no','no','no','no','no','yes','no','no','yes','yes','yes','no','no','yes','yes','no',7,'yes','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (6,'Moderator','#6dacad','yes','yes','no','yes','yes','no','yes','yes','no','yes','yes','yes','yes','no','yes','yes','yes',6,'yes','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (7,'Super Moderator','#9bd4e5','yes','yes','no','yes','no','no','yes','yes','yes','yes','yes','yes','yes','no','yes','yes','yes',5,'yes','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (8,'Administrator','#9172ec','yes','yes','yes','yes','yes','no','yes','yes','yes','yes','yes','yes','yes','yes','yes','no','no',4,'yes','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (3,'Power User','#F68700','yes','no','no','no','no','no','yes','no','no','yes','yes','yes','no','no','no','no','no',9,'yes','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (9,'Team Leader','#FF2000','yes','yes','yes','yes','yes','no','yes','yes','yes','yes','yes','yes','yes','yes','yes','no','no',3,'yes','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (10,'Coder','#ff9900','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','no','no',2,'yes','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (11,'Owner','#FF00DC','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','no','no',1,'yes','yes');
INSERT INTO `groups` (`group_id`, `level`, `Color`, `view_torrents`, `edit_torrents`, `delete_torrents`, `view_users`, `edit_users`, `delete_users`, `view_news`, `edit_news`, `delete_news`, `can_upload`, `can_download`, `view_forum`, `edit_forum`, `delete_forum`, `control_panel`, `staff_page`, `staff_public`, `staff_sort`, `can_pp`, `can_fp`) VALUES (12,'System','#c41b1b','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','no','no',1,'yes','yes');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:48
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` (`id`, `uri`, `name`) VALUES (1,'english.php','English');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:48
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `rules`
--

LOCK TABLES `rules` WRITE;
/*!40000 ALTER TABLE `rules` DISABLE KEYS */;
INSERT INTO `rules` (`id`, `title`, `text`, `public`, `class`) VALUES (1,'General rules - Breaking these rules can and will get you banned!','- We are a English only site, so please only talk in english! \r\n\r\n- Keep your overall ratio at or above 0.5 at all times! \r\n\r\n- Do not defy the moderators expressed wishes! ','yes',0);
INSERT INTO `rules` (`id`, `title`, `text`, `public`, `class`) VALUES (2,'General Forum Guidelines','- No aggressive behaviour or flaming in the forums. \r\n- No trashing of other peoples topics (i.e. SPAM). \r\n- No language other than English in the forums. \r\n- No links to warez or crack sites in the forums. \r\n- No serials, CD keys, passwords or cracks in the forums. \r\n- No requesting if the release is over 7 days old. \r\n- No bumping... (All bumped threads will be deleted.) \r\n- No double posting. If you wish to post again, and yours is the last post in the thread please use the EDIT function,instead of posting a double.\r\n- Please ensure all questions are posted in the correct section!','yes',0);
INSERT INTO `rules` (`id`, `title`, `text`, `public`, `class`) VALUES (3,'Moderating Rules','- The most important rule!; Use your better judgement! \r\n- Don\'t defy another mod in public, instead send a PM or make a post in the \"Site admin\". \r\n- Be tolerant! give the user(s) a chance to reform. \r\n- Don\'t act prematurely, Let the users make their mistake and THEN correct them. \r\n- Try correcting any \"off topics\" rather then closing the thread. \r\n- Move topics rather than locking / deleting them. \r\n- Be tolerant when moderating the Chit-chat section. (give them some slack) \r\n- If you lock a topic, Give a brief explanation as to why you\'re locking it. \r\n- Before banning a user, Send him/her a PM and If they reply, put them on a 2 week trial. \r\n- Don\'t ban a user until he or she has been a member for at least 4 weeks. \r\n- Always state a reason (in the user comment box) as to why the user is being banned. \r\n','no',5);
/*!40000 ALTER TABLE `rules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:48
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `stylesheets`
--

LOCK TABLES `stylesheets` WRITE;
/*!40000 ALTER TABLE `stylesheets` DISABLE KEYS */;
INSERT INTO `stylesheets` (`id`, `uri`, `name`) VALUES (1,'default','default');
/*!40000 ALTER TABLE `stylesheets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:48
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` (`task`, `last_time`) VALUES ('cleanup',1795028653);
INSERT INTO `tasks` (`task`, `last_time`) VALUES ('cleanup',1189677270);
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:48
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `torrentlang`
--

LOCK TABLES `torrentlang` WRITE;
/*!40000 ALTER TABLE `torrentlang` DISABLE KEYS */;
INSERT INTO `torrentlang` (`id`, `name`, `image`, `sort_index`) VALUES (1,'English','english.gif',1);
INSERT INTO `torrentlang` (`id`, `name`, `image`, `sort_index`) VALUES (2,'French','french.jpg',1);
INSERT INTO `torrentlang` (`id`, `name`, `image`, `sort_index`) VALUES (3,'German','german.jpg',1);
INSERT INTO `torrentlang` (`id`, `name`, `image`, `sort_index`) VALUES (4,'Italian','italian.jpg',1);
INSERT INTO `torrentlang` (`id`, `name`, `image`, `sort_index`) VALUES (5,'Japanese','japanese.jpg',1);
INSERT INTO `torrentlang` (`id`, `name`, `image`, `sort_index`) VALUES (6,'Spanish','spanish.jpg',1);
INSERT INTO `torrentlang` (`id`, `name`, `image`, `sort_index`) VALUES (7,'Russian','russian.jpg',1);
/*!40000 ALTER TABLE `torrentlang` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:48
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: luigi_db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `seedbonus`
--

LOCK TABLES `seedbonus` WRITE;
/*!40000 ALTER TABLE `seedbonus` DISABLE KEYS */;
/*!40000 ALTER TABLE `seedbonus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 20:40:48
